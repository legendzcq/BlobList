//
//  AFURLResponseSerializationViewController.m
//  AFNetWorking3.X源码阅读
//
//  Created by huangchengdu on 17/4/26.
//  Copyright © 2017年 huangchengdu. All rights reserved.
//

#import "AFURLResponseSerializationViewController.h"

@interface AFURLResponseSerializationViewController ()

@end

@implementation AFURLResponseSerializationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (IBAction)clickButton1:(id)sender {
    NSLog(@"呵呵");
}

- (IBAction)clickButton2:(id)sender {
    
}


- (IBAction)clickButton3:(id)sender {
}

@end
