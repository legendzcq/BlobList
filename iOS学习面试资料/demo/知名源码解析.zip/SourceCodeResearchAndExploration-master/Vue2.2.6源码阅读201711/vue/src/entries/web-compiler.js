/* @flow */

export { parseComponent } from 'sfc/parser'
export { compile, compileToFunctions } from 'web/compiler/index'
