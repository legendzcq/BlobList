# weex-template-compiler

> This package is auto-generated. For pull requests please see [src/entries/weex-compiler.js](https://github.com/vuejs/vue/blob/dev/src/entries/weex-compiler.js).
