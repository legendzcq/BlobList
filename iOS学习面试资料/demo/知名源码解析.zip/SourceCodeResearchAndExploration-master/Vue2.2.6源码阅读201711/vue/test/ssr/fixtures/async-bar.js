module.exports = {
  render (h) {
    return h('div', 'async bar')
  }
}
