//
//  LSViewTestKVO.h
//  fds11
//
//  Created by liusong on 2018/6/28.
//  Copyright © 2018年 liusong. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface LSViewTestKVO : UIView
@property (nonatomic,weak) UIViewController *con;
@end
