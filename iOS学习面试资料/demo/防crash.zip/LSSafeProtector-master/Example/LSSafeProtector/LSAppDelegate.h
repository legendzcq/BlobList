//
//  LSAppDelegate.h
//  LSSafeProtector
//
//  Created by liusong on 08/09/2018.
//  Copyright (c) 2018 liusong. All rights reserved.
//

@import UIKit;

@interface LSAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
