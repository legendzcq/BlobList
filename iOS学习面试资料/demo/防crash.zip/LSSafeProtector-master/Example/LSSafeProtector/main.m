//
//  main.m
//  LSSafeProtector
//
//  Created by liusong on 08/09/2018.
//  Copyright (c) 2018 liusong. All rights reserved.
//

@import UIKit;
#import "LSAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([LSAppDelegate class]));
    }
}
