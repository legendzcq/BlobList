//
//  LSViewTestKVOSuper.h
//  LSSafeProtector
//
//  Created by liusong on 2018/7/2.
//  Copyright © 2018年 liusong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LSViewTestKVOSuper : UIView

@end
