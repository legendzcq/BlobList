//
//  AppDelegate.h
//  GCD队列与执行
//
//  Created by MisterBooo on 2018/4/28.
//  Copyright © 2018年 MisterBooo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

