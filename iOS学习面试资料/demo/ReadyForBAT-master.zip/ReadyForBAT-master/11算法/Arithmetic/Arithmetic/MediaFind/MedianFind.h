//
//  MediaFind.h
//  Arithmetic
//
//  Created by MisterBooo on 2018/5/5.
//  Copyright © 2018年 MisterBooo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MedianFind : NSObject
// 无序数组中位数查找
int findMedian(int a[], int aLen);

@end
