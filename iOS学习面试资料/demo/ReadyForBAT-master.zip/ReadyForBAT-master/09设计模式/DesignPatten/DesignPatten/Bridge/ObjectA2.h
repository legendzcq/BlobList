//
//  ObjectA2.h
//  DesignPatten
//
//  Created by MisterBooo on 2018/5/4.
//  Copyright © 2018年 MisterBooo. All rights reserved.
//

#import "BaseObjectA.h"

@interface ObjectA2 : BaseObjectA

@end
