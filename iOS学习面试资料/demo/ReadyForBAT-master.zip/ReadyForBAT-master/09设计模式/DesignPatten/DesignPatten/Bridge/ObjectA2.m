//
//  ObjectA2.m
//  DesignPatten
//
//  Created by MisterBooo on 2018/5/4.
//  Copyright © 2018年 MisterBooo. All rights reserved.
//

#import "ObjectA2.h"

@implementation ObjectA2

@end
