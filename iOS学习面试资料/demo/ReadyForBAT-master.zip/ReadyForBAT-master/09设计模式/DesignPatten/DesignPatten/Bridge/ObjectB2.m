//
//  ObjectB2.m
//  DesignPatten
//
//  Created by MisterBooo on 2018/5/4.
//  Copyright © 2018年 MisterBooo. All rights reserved.
//

#import "ObjectB2.h"

@implementation ObjectB2

@end
