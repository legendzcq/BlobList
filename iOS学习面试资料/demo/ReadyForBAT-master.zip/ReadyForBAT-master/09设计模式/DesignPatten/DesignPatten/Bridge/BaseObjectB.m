//
//  BaseObjectB.m
//  DesignPatten
//
//  Created by MisterBooo on 2018/5/4.
//  Copyright © 2018年 MisterBooo. All rights reserved.
//

#import "BaseObjectB.h"

@implementation BaseObjectB
- (void)fetchData{
    NSLog(@"BaseObjectB fetchData");
    //子类重写
}
@end
