
[How to build libobjc (objc4-680)](http://blog.csdn.net/wotors/article/details/52489464) (Chinese Version)

[How to build libobjc (objc4-706)](http://blog.csdn.net/wotors/article/details/54426316) (Chinese Version)

