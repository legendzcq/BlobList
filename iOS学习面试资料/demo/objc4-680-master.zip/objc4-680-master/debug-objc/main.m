//
//  main.m
//  debug-objc
//
//  Created by maninthemiddle on 9/9/16.
//
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
    }
    return 0;
}
