//
//  MRRARR.h
//  TestARRLayouts
//
//  Created by Patrick Beard on 3/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ARRBase.h"

@interface MRRARR : ARRBase
@property(retain) id dataSource;
@end
