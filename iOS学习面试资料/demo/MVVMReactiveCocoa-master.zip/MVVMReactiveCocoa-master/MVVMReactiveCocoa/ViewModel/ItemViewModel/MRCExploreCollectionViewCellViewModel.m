//
//  MRCExploreCollectionViewCellViewModel.m
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 16/3/27.
//  Copyright © 2016年 leichunfeng. All rights reserved.
//

#import "MRCExploreCollectionViewCellViewModel.h"

@implementation MRCExploreCollectionViewCellViewModel

@end
