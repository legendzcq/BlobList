//
//  MRCReposSearchResultsItemViewModel.h
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 15/5/11.
//  Copyright (c) 2015年 leichunfeng. All rights reserved.
//

#import "MRCReposItemViewModel.h"

@interface MRCReposSearchResultsItemViewModel : MRCReposItemViewModel

@end
