//
//  MRCExploreItemViewModel.m
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 16/3/26.
//  Copyright © 2016年 leichunfeng. All rights reserved.
//

#import "MRCExploreItemViewModel.h"

@implementation MRCExploreItemViewModel

@end
