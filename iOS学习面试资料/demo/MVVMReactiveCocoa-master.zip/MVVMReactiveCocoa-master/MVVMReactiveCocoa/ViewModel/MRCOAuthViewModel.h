//
//  MRCOAuthViewModel.h
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 16/5/15.
//  Copyright © 2016年 leichunfeng. All rights reserved.
//

#import "MRCWebViewModel.h"

@interface MRCOAuthViewModel : MRCWebViewModel

@property (nonatomic, copy, readonly) NSString *UUIDString;

@end
