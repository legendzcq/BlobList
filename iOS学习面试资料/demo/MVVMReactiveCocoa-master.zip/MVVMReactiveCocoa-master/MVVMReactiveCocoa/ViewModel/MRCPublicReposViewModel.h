//
//  MRCPublicReposViewModel.h
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 15/6/19.
//  Copyright (c) 2015年 leichunfeng. All rights reserved.
//

#import "MRCOwnedReposViewModel.h"

@interface MRCPublicReposViewModel : MRCOwnedReposViewModel

@end
