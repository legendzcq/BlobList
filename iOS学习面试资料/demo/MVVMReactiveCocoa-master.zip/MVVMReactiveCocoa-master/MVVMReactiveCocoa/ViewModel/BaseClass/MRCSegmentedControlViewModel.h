//
//  MRCSegmentedControlViewModel.h
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 15/1/18.
//  Copyright (c) 2015年 leichunfeng. All rights reserved.
//

#import "MRCViewModel.h"

@interface MRCSegmentedControlViewModel : MRCViewModel

@property (nonatomic, copy) NSArray *viewModels;

@end
