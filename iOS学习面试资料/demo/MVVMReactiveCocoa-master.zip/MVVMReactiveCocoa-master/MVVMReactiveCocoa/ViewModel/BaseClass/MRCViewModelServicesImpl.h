//
//  MRCViewModelServicesImpl.h
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 14/12/27.
//  Copyright (c) 2014年 leichunfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MRCViewModelServices.h"

@interface MRCViewModelServicesImpl : NSObject <MRCViewModelServices>

@end
