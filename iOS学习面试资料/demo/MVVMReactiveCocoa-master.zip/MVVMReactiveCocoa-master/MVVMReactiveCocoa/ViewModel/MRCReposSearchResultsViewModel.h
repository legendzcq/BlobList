//
//  MRCReposSearchResultsViewModel.h
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 15/5/10.
//  Copyright (c) 2015年 leichunfeng. All rights reserved.
//

#import "MRCOwnedReposViewModel.h"

@interface MRCReposSearchResultsViewModel : MRCOwnedReposViewModel

@property (nonatomic, copy) NSString *query;
@property (nonatomic, copy) NSDictionary *language;

@end
