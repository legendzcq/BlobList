//
//  MRCErrors.m
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 14/12/28.
//  Copyright (c) 2014年 leichunfeng. All rights reserved.
//

#import "MRCErrors.h"

NSString * const MRCErrorDomain = @"com.leichunfeng.ErrorDomain";

@implementation MRCErrors

@end
