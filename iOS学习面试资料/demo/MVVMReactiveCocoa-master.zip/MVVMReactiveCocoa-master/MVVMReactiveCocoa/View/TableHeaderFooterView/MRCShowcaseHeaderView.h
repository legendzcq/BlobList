//
//  MRCShowcaseHeaderView.h
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 16/4/24.
//  Copyright © 2016年 leichunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MRCReactiveView.h"

@interface MRCShowcaseHeaderView : UIView <MRCReactiveView>

@end
