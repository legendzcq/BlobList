//
//  MRCTrendingReposViewController.h
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 16/5/7.
//  Copyright © 2016年 leichunfeng. All rights reserved.
//

#import "MRCViewController.h"

@interface MRCTrendingReposViewController : MRCViewController

@end
