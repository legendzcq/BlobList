//
//  MRCButton.h
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 15/1/6.
//  Copyright (c) 2015年 leichunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MRCButton : UIButton

@end
