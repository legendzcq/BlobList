//
//  MRCTrendingViewController.m
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 15/10/20.
//  Copyright © 2015年 leichunfeng. All rights reserved.
//

#import "MRCTrendingViewController.h"
#import "MRCTrendingViewModel.h"
#import "MRCTrendingSettingsViewModel.h"

@implementation MRCTrendingViewController

- (UIEdgeInsets)contentInset {
    return iPhoneX ? UIEdgeInsetsMake(88 + 45, 0, 0, 0) : UIEdgeInsetsMake(64 + 45, 0, 0, 0);
}

@end
