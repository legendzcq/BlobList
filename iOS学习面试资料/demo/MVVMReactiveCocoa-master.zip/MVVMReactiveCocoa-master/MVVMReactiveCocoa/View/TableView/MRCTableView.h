//
//  MRCTableView.h
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 16/9/21.
//  Copyright © 2016年 leichunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MRCTableView : UITableView

@end
