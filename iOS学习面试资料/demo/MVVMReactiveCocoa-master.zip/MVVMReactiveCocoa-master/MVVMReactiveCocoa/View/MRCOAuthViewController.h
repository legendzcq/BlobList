//
//  MRCOAuthViewController.h
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 16/5/15.
//  Copyright © 2016年 leichunfeng. All rights reserved.
//

#import "MRCWebViewController.h"

@interface MRCOAuthViewController : MRCWebViewController

@end
