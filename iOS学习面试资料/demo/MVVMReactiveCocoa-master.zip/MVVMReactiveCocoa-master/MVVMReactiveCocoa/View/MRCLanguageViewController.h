//
//  MRCLanguageViewController.h
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 16/4/24.
//  Copyright © 2016年 leichunfeng. All rights reserved.
//

#import "MRCTableViewController.h"

@interface MRCLanguageViewController : MRCTableViewController

@end
