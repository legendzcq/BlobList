//
//  MRCReposSearchResultsViewController.h
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 15/5/10.
//  Copyright (c) 2015年 leichunfeng. All rights reserved.
//

#import "MRCOwnedReposViewController.h"

@interface MRCReposSearchResultsViewController : MRCOwnedReposViewController

@end
