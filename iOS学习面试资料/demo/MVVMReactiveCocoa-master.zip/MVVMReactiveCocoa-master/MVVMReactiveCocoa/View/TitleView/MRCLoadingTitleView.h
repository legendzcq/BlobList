//
//  MRCLoadingTitleView.h
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 15/7/24.
//  Copyright (c) 2015年 leichunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MRCLoadingTitleView : UIView

@end
