//
//  MRCTrendingSettingsViewController.h
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 15/10/21.
//  Copyright © 2015年 leichunfeng. All rights reserved.
//

#import "MRCTableViewController.h"

@interface MRCTrendingSettingsViewController : MRCTableViewController

@end
