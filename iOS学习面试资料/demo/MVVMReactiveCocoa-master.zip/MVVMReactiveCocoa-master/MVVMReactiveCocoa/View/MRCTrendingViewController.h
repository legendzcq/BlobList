//
//  MRCTrendingViewController.h
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 15/10/20.
//  Copyright © 2015年 leichunfeng. All rights reserved.
//

#import "MRCOwnedReposViewController.h"

@interface MRCTrendingViewController : MRCOwnedReposViewController

@end
