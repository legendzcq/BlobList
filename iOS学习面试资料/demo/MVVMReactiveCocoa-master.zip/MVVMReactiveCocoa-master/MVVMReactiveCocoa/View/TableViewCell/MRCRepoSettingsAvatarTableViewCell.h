//
//  MRCRepoSettingsAvatarTableViewCell.h
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 15/5/15.
//  Copyright (c) 2015年 leichunfeng. All rights reserved.
//

#import "MRCTableViewCellStyleValue1.h"

@interface MRCRepoSettingsAvatarTableViewCell : MRCTableViewCellStyleValue1

@property (nonatomic, strong, readonly) UIImageView *imageView;

@end
