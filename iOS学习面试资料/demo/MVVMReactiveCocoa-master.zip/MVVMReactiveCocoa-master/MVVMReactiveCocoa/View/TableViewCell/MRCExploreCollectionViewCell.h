//
//  MRCExploreCollectionViewCell.h
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 16/3/27.
//  Copyright © 2016年 leichunfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MRCReactiveView.h"

@interface MRCExploreCollectionViewCell : UICollectionViewCell <MRCReactiveView>

@end
