//
//  MRCTableViewCellStyleValue1.m
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 15/3/5.
//  Copyright (c) 2015年 leichunfeng. All rights reserved.
//

#import "MRCTableViewCellStyleValue1.h"

@implementation MRCTableViewCellStyleValue1

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    return [super initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:reuseIdentifier];
}

@end
