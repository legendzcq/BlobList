//
//  FMDatabaseQueue+MRCHelper.h
//  MVVMReactiveCocoa
//
//  Created by leichunfeng on 15/6/22.
//  Copyright (c) 2015年 leichunfeng. All rights reserved.
//

#import "FMDatabaseQueue.h"

@interface FMDatabaseQueue (MRCHelper)

+ (instancetype)sharedInstance;

@end
