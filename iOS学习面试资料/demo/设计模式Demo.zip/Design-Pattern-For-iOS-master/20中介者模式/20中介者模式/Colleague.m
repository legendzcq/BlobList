//
//  Colleague.m
//  20中介者模式
//
//  Created by huangchengdu on 17/5/22.
//  Copyright © 2017年 黄成都. All rights reserved.
//

#import "Colleague.h"

@implementation Colleague

@end
