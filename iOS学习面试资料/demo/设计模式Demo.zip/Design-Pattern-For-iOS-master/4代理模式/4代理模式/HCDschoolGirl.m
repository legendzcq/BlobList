//
//  HCDschoolGirl.m
//  4代理模式
//
//  Created by yifan on 15/8/12.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

#import "HCDschoolGirl.h"

@implementation HCDschoolGirl

@end
