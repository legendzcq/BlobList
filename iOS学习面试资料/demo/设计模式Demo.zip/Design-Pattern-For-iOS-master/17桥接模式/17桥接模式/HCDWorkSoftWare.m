//
//  HCDWorkSoftWare.m
//  17桥接模式
//
//  Created by huangchengdu on 17/5/18.
//  Copyright © 2017年 黄成都. All rights reserved.
//

#import "HCDWorkSoftWare.h"
#import "HCDSoftware.h"

@interface HCDWorkSoftWare ()

@end

@implementation HCDWorkSoftWare

-(void)runWord{
    NSLog(@"WorkSoftWare打开办公软件");
}

-(void)runXcode{
    NSLog(@"WorkSoftWare打开Xcode");
}

@end
