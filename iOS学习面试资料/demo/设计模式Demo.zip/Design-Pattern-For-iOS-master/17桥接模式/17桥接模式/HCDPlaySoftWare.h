//
//  HCDPlaySoftWare.h
//  17桥接模式
//
//  Created by huangchengdu on 17/5/18.
//  Copyright © 2017年 黄成都. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HCDSoftware.h"

@interface HCDPlaySoftWare : NSObject<HCDSoftware>

@end
