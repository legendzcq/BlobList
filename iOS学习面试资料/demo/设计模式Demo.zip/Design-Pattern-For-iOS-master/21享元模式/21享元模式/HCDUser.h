//
//  HCDUser.h
//  21享元模式
//
//  Created by yifan on 15/8/27.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HCDUser : NSObject
@property(nonatomic,strong)NSString *name;
@end
