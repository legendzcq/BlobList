//
//  HCDUser.m
//  21享元模式
//
//  Created by yifan on 15/8/27.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

#import "HCDUser.h"

@implementation HCDUser

@end
