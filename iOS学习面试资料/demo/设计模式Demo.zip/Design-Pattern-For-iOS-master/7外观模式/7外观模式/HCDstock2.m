//
//  HCDstock2.m
//  7外观模式
//
//  Created by yifan on 15/8/13.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

#import "HCDstock2.h"

@implementation HCDstock2
-(void)buy{
    NSLog(@"买入股票2");
}
-(void)sell{
    NSLog(@"卖出股票2");
}
@end
