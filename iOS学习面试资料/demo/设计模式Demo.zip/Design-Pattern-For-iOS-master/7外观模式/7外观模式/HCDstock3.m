//
//  HCDstock3.m
//  7外观模式
//
//  Created by yifan on 15/8/13.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

#import "HCDstock3.h"

@implementation HCDstock3
-(void)buy{
    NSLog(@"买入股票3");
}
-(void)sell{
    NSLog(@"卖出股票3");
}
@end
