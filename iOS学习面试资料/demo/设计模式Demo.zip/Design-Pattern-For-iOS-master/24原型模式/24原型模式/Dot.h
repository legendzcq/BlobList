//
//  Dot.h
//  24原型模式
//
//  Created by huangchengdu on 17/5/16.
//  Copyright © 2017年 huangchengdu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Mark.h"

@interface Dot : NSObject<Mark,NSCopying>

@end
