//
//  HCDLeg.m
//  8建造者模式
//
//  Created by huangchengdu on 17/5/17.
//  Copyright © 2017年 黄成都. All rights reserved.
//

#import "HCDLeg.h"

@implementation HCDLeg

-(void)work{
    NSLog(@"成功构建了腿------HCDLeg");
}

@end
