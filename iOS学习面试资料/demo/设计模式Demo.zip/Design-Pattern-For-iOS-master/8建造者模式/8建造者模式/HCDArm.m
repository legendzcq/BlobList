//
//  HCDArm.m
//  8建造者模式
//
//  Created by huangchengdu on 17/5/17.
//  Copyright © 2017年 黄成都. All rights reserved.
//

#import "HCDArm.h"

@implementation HCDArm

-(void)work{
    NSLog(@"成功构建了手臂------HCDArm");
}

@end
