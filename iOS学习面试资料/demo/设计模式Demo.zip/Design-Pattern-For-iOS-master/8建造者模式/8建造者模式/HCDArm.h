//
//  HCDArm.h
//  8建造者模式
//
//  Created by huangchengdu on 17/5/17.
//  Copyright © 2017年 黄成都. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HCDArm : NSObject

-(void)work;

@end
