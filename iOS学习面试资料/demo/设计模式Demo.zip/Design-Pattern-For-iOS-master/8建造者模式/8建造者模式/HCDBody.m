//
//  HCDBody.m
//  8建造者模式
//
//  Created by huangchengdu on 17/5/17.
//  Copyright © 2017年 黄成都. All rights reserved.
//

#import "HCDBody.h"

@implementation HCDBody

-(void)work{
    NSLog(@"成功构建了身体-----HCDBody");
}

@end
