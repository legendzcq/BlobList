//
//  HCDDuckOrder.h
//  18命令模式
//
//  Created by huangchengdu on 17/6/1.
//  Copyright © 2017年 黄成都. All rights reserved.
//

#import "HCDOrder.h"

@interface HCDDuckOrder : HCDOrder

@end
