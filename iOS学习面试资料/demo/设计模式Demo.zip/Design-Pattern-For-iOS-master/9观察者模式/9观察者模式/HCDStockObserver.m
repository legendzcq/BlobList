//
//  HCDStockObserver.m
//  9观察者模式
//
//  Created by yifan on 15/8/13.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

#import "HCDStockObserver.h"

@implementation HCDStockObserver
-(void)update{
    NSLog(@"操。。老板回来了,带会儿再看");
}
@end
