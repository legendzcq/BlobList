
module.exports = {
    key:' value'
}