# 自定义转场动画

这是我为[iOS自定义转场动画实战讲解](http://www.jianshu.com/p/ea0132738057)提供的demo，使用Swift和Snapkit。

如果您使用的是OC和Storyboard，可以参考[这个demo](https://github.com/bestswifter/MySampleCode/tree/master/CustomTransition/CustomTransition-OC)

demo效果如下：

![demo演示](http://images.bestswifter.com/CustomTransition/demo.gif)
