//
//  EOCSmithPerson.h
//  EffectiveObjectiveC
//
//  Created by 张星宇 on 16/3/24.
//  Copyright © 2016年 zxy. All rights reserved.
//

#import "EOCPerson.h"

@interface EOCSmithPerson : EOCPerson

@end
