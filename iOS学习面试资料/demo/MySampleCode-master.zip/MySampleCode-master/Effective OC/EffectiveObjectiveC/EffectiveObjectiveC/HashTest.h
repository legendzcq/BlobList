//
//  HashTest.h
//  EffectiveObjectiveC
//
//  Created by 张星宇 on 16/3/25.
//  Copyright © 2016年 zxy. All rights reserved.
//

#import "EOCPerson.h"

@interface HashTest : EOCPerson

- (void)testMutableCollection;

@end
