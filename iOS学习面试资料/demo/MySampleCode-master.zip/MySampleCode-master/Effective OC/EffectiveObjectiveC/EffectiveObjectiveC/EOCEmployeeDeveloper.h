//
//  EOCEmployeeDeveloper.h
//  EffectiveObjectiveC
//
//  Created by 张星宇 on 16/3/25.
//  Copyright © 2016年 zxy. All rights reserved.
//

#import "EOCEmployee.h"

@interface EOCEmployeeDeveloper : EOCEmployee

@end
