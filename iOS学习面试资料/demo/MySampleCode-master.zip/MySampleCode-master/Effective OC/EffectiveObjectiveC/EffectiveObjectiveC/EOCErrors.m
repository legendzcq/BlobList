//
//  EOCErrors.m
//  EffectiveObjectiveC
//
//  Created by 张星宇 on 16/3/27.
//  Copyright © 2016年 zxy. All rights reserved.
//

#import "EOCErrors.h"

NSString *const EOCErrorDomain = @"EOCErrorDomain";

@implementation EOCErrors

@end
