//
//  Literal.h
//  EffectiveObjectiveC
//
//  Created by 张星宇 on 16/3/24.
//  Copyright © 2016年 zxy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Literal : NSObject

@property (nonatomic, strong) NSArray *animals;
@property (nonatomic, strong) NSDictionary *personData;

@end
