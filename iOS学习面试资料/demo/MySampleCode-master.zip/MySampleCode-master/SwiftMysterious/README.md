# Swift中你应该知道的一些有用的tips

这份代码是[《Swift中你应该知道的一些有用的tips》](http://www.jianshu.com/p/a11c6060176c)一文的demo,主要介绍了Swift中很不错，但也很容易忽视的小tip