//
//  main.swift
//  SwiftMysterious
//
//  Created by 张星宇 on 16/1/29.
//  Copyright © 2016年 zxy. All rights reserved.
//

import Foundation

lazyVariable()  // 默认的lazy属性实现
inlineLazyVariable()    // 内联的lazy属性实现

specialLitertalExpression() // 用于调试的特殊字面量表达式

normalBreak()   // 正常的break循环
breakWithLoopLabel()    // 使用循环标签的break循环
