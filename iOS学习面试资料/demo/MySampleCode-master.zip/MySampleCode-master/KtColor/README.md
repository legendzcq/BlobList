# 当 UIColor 遇上 Swift

这个 demo 主要用于分析如何利用 Swift 的语法特性简化创建 `UIColor`对象的过程。具体文章可以参考我的博客：[当UIColor遇上 Swift](http://www.jianshu.com/p/f2173235cde8)
