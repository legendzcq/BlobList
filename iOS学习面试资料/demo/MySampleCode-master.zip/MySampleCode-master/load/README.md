# 细说OC中的load和initialize方法

这份代码是[《细说OC中的load和initialize方法》](http://www.jianshu.com/p/d25f691f0b07)一文的demo,主要介绍了OC中的`load`和`initialize`方法
