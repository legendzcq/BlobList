//
//  ViewController.h
//  KtTableView
//
//  Created by bestswifter on 16/4/13.
//  Copyright © 2016年 zxy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KtRefreshTableViewController.h"

@interface KTMainViewController : KtRefreshTableViewController

@end

