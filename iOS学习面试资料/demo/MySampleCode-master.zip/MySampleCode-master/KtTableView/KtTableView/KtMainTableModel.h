//
//  KtMainTableModel.h
//  KtTableView
//
//  Created by bestswifter on 16/5/13.
//  Copyright © 2016年 zxy. All rights reserved.
//

#import "KtBaseListModel.h"
#import "KtMainTableItem.h"

@interface KtMainTableModel : KtBaseListModel

@property (nonatomic, strong) KtMainTableItem *tableViewItem;

@end
