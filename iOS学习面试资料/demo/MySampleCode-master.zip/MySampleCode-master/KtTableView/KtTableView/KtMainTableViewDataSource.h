//
//  KtMainTableViewDataSource.h
//  KtTableView
//
//  Created by bestswifter on 16/4/13.
//  Copyright © 2016年 zxy. All rights reserved.
//

#import "KtTableViewDataSource.h"

@interface KtMainTableViewDataSource : KtTableViewDataSource

@end
