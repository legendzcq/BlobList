//
//  BSStaticLibraryOne.m
//  BSStaticLibraryOne
//
//  Created by 张星宇 on 2017/1/7.
//  Copyright © 2017年 bestswifter. All rights reserved.
//

#import "BSStaticLibraryOne.h"

@implementation BSStaticLibraryOne

- (void)saySomething {
    NSLog(@"In Library: BSStaticLibraryOne");
}

@end
