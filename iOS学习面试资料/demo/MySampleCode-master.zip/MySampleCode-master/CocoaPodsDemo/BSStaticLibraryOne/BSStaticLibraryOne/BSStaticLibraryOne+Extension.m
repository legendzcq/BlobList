//
//  BSStaticLibraryOne+Extension.m
//  BSStaticLibraryOne
//
//  Created by 张星宇 on 2017/1/7.
//  Copyright © 2017年 bestswifter. All rights reserved.
//

#import "BSStaticLibraryOne+Extension.h"

@implementation BSStaticLibraryOne (Extension)

- (void)sayOtherThing {
    NSLog(@"In File: BSStaticLibraryOne + Extension");
}

@end
