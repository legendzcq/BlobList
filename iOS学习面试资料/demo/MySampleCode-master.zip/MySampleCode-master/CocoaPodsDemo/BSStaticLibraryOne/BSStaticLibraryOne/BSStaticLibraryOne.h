//
//  BSStaticLibraryOne.h
//  BSStaticLibraryOne
//
//  Created by 张星宇 on 2017/1/7.
//  Copyright © 2017年 bestswifter. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BSStaticLibraryOne : NSObject

- (void)saySomething;

@end
