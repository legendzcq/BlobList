//
//  BSStaticLibraryTwo.m
//  BSStaticLibraryTwo
//
//  Created by 张星宇 on 2017/1/8.
//  Copyright © 2017年 bestswifter. All rights reserved.
//

#import "BSStaticLibraryTwo.h"

@implementation BSStaticLibraryTwo

- (void)saySomething {
    NSLog(@"In Library: BSStaticLibraryTwo");
}

@end
