//
//  BSStaticLibraryTwo.h
//  BSStaticLibraryTwo
//
//  Created by 张星宇 on 2017/1/8.
//  Copyright © 2017年 bestswifter. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BSStaticLibraryTwo : NSObject

- (void)saySomething;

@end
