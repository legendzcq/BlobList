//
//  AppDelegate.h
//  ShellProject
//
//  Created by 张星宇 on 2017/1/7.
//  Copyright © 2017年 bestswifter. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

