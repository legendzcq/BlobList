# Runtime相关的方法

这份代码是[《歪解Runtime》](http://www.jianshu.com/p/295cd2b6b42e)一文的demo,主要涉及Runtime和方法调用、转发相关的知识
