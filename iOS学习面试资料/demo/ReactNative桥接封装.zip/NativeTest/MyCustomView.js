// JavaScript
var { requireNativeComponent } = require('react-native');

// requireNativeComponent 自动把这个组件提供给 "MyCustomView"
module.exports = requireNativeComponent('MyCustomView', null);