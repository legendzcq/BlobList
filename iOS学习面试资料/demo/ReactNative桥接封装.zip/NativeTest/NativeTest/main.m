//
//  main.m
//  NativeTest
//
//  Created by 朱源浩 on 16/8/18.
//  Copyright © 2016年 稀饭. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
