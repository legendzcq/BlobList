//
//  RNViewController.m
//  NativeTest
//
//  Created by 朱源浩 on 16/8/30.
//  Copyright © 2016年 稀饭. All rights reserved.
//

#import "RNViewController.h"

#import "RCTBundleURLProvider.h"
#import "RCTRootView.h"

@interface RNViewController ()

@end

@implementation RNViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    
    NSURL *jsCodeLocation;
    
#ifdef DEBUG
    jsCodeLocation = [[RCTBundleURLProvider sharedSettings] jsBundleURLForBundleRoot:@"index.ios" fallbackResource:nil];
#else
    jsCodeLocation = [CodePush bundleURLForResource:@"index"];
#endif
    
    RCTRootView *rootView = [[RCTRootView alloc] initWithBundleURL:jsCodeLocation
                                                        moduleName:@"NativeTest2"
                                                 initialProperties:nil
                                                     launchOptions:nil];
    
    self.view = rootView;
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




@end
