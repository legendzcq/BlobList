//
//  TestScrollView.m
//  NativeTest
//
//  Created by 朱源浩 on 16/8/27.
//  Copyright © 2016年 稀饭. All rights reserved.
//

#import "TestScrollView.h"

@implementation TestScrollView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
