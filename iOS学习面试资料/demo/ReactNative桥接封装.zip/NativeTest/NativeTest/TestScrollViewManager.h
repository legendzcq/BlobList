//
//  TestScrollViewManager.h
//  NativeTest
//
//  Created by 朱源浩 on 16/8/27.
//  Copyright © 2016年 稀饭. All rights reserved.
//

#import "RCTViewManager.h"

@interface TestScrollViewManager : RCTViewManager

@end
