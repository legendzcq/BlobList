//
//  RCTMapManager.m
//  NativeTest
//
//  Created by 朱源浩 on 16/8/26.
//  Copyright © 2016年 稀饭. All rights reserved.
//

#import "RCTMappManager.h"
#import <MapKit/MapKit.h>


@implementation RCTMappManager

RCT_EXPORT_MODULE()

RCT_EXPORT_VIEW_PROPERTY(pitchEnabled, BOOL)

- (UIView *)view
{
    return [[MKMapView alloc] init];
}

@end
