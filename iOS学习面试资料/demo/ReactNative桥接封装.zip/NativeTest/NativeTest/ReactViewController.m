//
//  ReactViewController.m
//  NativeTest
//
//  Created by 朱源浩 on 16/8/18.
//  Copyright © 2016年 稀饭. All rights reserved.
//

#import "ReactViewController.h"

#import "RCTBundleURLProvider.h"
#import "RCTRootView.h"

#import "CodePush.h"

@interface ReactViewController ()


@property (weak, nonatomic) IBOutlet UILabel *infoLabel;

@property (weak, nonatomic) IBOutlet UIView *RNRootView;


@end


@implementation ReactViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(dealWithRN:)
                                                 name:@"react_native_test"
                                               object:nil];
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    [self initUI];
}

- (void)initUI
{
    NSURL *jsCodeLocation;
    
#ifdef DEBUG
    jsCodeLocation = [[RCTBundleURLProvider sharedSettings] jsBundleURLForBundleRoot:@"index.ios" fallbackResource:nil];
#else
    jsCodeLocation = [CodePush bundleURLForResource:@"index"];
#endif
    
    RCTRootView *rootView = [[RCTRootView alloc] initWithBundleURL:jsCodeLocation
                                                        moduleName:@"NativeTest"
                                                 initialProperties:nil
                                                     launchOptions:nil];
    
    [_RNRootView layoutIfNeeded];
    
    [rootView setFrame:_RNRootView.bounds];
    
    rootView.layer.borderWidth = 3;
    rootView.layer.borderColor = [[UIColor blackColor] CGColor];

    
    [_RNRootView addSubview:rootView];
    
//    [rootView setFrame:CGRectMake(0, 0, self.view .frame.size.width, self.view.frame.size.height*2/3)];
    
//    [self.view addSubview:rootView];
    
//    UIView *localView = [[UIView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height*2/3, self.view .frame.size.width, self.view.frame.size.height/3)];
//    localView.backgroundColor = [UIColor orangeColor];
//    [self.view addSubview:localView];
    
    _infoLabel.numberOfLines = 0;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealWithRN:(NSNotification *)notification
{
    NSDictionary *theData = [notification userInfo];
    
    NSString *info = theData[@"info"];
    
    _infoLabel.text = info;
}

- (IBAction)testSendMessage:(id)sender {
    
    _infoLabel.text = @"测试发送事件给JavaScript";
    [[NSNotificationCenter defaultCenter] postNotificationName:@"receive_notification_test" object:nil userInfo:@{@"name": @"test send message"}];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
