//
//  ForwardInvocation.m
//  消息转发Demo
//
//  Created by legend on 2018/9/2.
//  Copyright © 2018年 legend. All rights reserved.
//

#import "ForwardInvocation.h"

@implementation ForwardInvocation
-(void)appendString:(NSString*)str{
    
    NSLog(@"%@===%@",NSStringFromClass([self class]),NSStringFromSelector(_cmd));
    
}


@end
