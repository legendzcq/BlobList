//
//  SonPerson.m
//  消息转发Demo
//
//  Created by legend on 2018/9/2.
//  Copyright © 2018年 legend. All rights reserved.
//

#import "SonPerson.h"
#import <objc/runtime.h>
#import "ForwardPerson.h"
#import "ForwardInvocation.h"

@interface SonPerson()
@property(nonatomic,strong)ForwardInvocation *invocation;
@end


@implementation SonPerson
void dynamicAdditionMethodIMP(id self,SEL _cmd){
    
    NSLog(@"dynamicAdditionMethodIMP");
    
}

+(BOOL)resolveClassMethod:(SEL)sel {
        NSLog(@"resolveInstanceMethod: %@", NSStringFromSelector(sel));
    return [super resolveClassMethod:sel];
}
+(BOOL)resolveInstanceMethod:(SEL)sel {
    NSLog(@"resolveInstanceMethod: %@", NSStringFromSelector(sel));
    
//    if(sel ==@selector(appendString:)) {
//        
//    class_addMethod([self class], sel, (IMP)dynamicAdditionMethodIMP,"v@:");
//
//        
//    return YES;
//        
// }
    
    
    return [super resolveInstanceMethod:sel];
}

-(void)abc {
    NSLog(@"abcPrint");
}
- (id)forwardingTargetForSelector:(SEL)aSelector{
    
    NSLog(@"forwardingTargetForSelector");
    
    
    
    return nil;
//    [ForwardPerson new];
    
}

- (NSMethodSignature*)methodSignatureForSelector:(SEL)aSelector{
    
    NSMethodSignature*signature = [super methodSignatureForSelector:aSelector];
    
    if(!signature){
        
        if ([ForwardInvocation instancesRespondToSelector:aSelector]){
            
            signature = [ForwardInvocation instanceMethodSignatureForSelector:aSelector];
            
        }
        
    }
    
    return signature;
    
}



-(void)forwardInvocation:(NSInvocation*)anInvocation{
    
        NSLog(@"forwardInvocation");
    
        if ([ForwardInvocation instancesRespondToSelector:anInvocation.selector]) {
        
                [anInvocation invokeWithTarget:self.invocation];
        
           }
    
}


@end
