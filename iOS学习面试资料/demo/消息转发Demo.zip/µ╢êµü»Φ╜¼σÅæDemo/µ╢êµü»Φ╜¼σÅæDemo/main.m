//
//  main.m
//  消息转发Demo
//
//  Created by legend on 2018/9/2.
//  Copyright © 2018年 legend. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
