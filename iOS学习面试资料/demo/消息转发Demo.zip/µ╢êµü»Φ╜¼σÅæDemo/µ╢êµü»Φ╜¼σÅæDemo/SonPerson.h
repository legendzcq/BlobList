//
//  SonPerson.h
//  消息转发Demo
//
//  Created by legend on 2018/9/2.
//  Copyright © 2018年 legend. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SonPerson : NSObject

@end
