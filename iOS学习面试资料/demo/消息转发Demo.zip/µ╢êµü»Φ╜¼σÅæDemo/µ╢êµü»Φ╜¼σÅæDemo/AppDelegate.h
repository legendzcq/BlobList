//
//  AppDelegate.h
//  消息转发Demo
//
//  Created by legend on 2018/9/2.
//  Copyright © 2018年 legend. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

