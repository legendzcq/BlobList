//
//  ViewController.m
//  消息转发Demo
//
//  Created by legend on 2018/9/2.
//  Copyright © 2018年 legend. All rights reserved.
//

#import "ViewController.h"
#import "SonPerson.h"
@interface ViewController ()
@property(nonatomic,strong)UIView * oneView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    id person = [[SonPerson alloc] init];
    [person appendString:@""];
    
    NSTimer * myTimer = [NSTimer timerWithTimeInterval:1.0 target:self selector:@selector(doSomeThing:) userInfo:nil repeats:YES];
    [myTimer fire];
    [[NSRunLoop mainRunLoop] addTimer:myTimer forMode:NSDefaultRunLoopMode];
    
    UIView * oneVIew  = [[UIView alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
    [self.view addSubview:oneVIew];
    oneVIew.backgroundColor = [UIColor redColor];
    self.oneView = oneVIew;
    

}

-(void)doSomeThing:(NSTimer *)sender {
    NSLog(@"111");
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    dispatch_queue_t queue = dispatch_queue_create("com.test", DISPATCH_QUEUE_CONCURRENT);
    dispatch_async(queue, ^{
        NSLog(@"%@",[NSThread currentThread]);
        self.oneView.backgroundColor = [UIColor yellowColor];
    });
}

@end
