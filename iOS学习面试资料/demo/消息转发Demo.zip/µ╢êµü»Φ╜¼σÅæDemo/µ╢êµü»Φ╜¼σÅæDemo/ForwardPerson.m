//
//  ForwardPerson.m
//  消息转发Demo
//
//  Created by legend on 2018/9/2.
//  Copyright © 2018年 legend. All rights reserved.
//

#import "ForwardPerson.h"

@implementation ForwardPerson
+(BOOL)resolveInstanceMethod:(SEL)sel {
    NSLog(@"resolveInstanceMethod: %@", NSStringFromSelector(sel));
    
    //    if(sel ==@selector(appendString:)) {
    //
    //    class_addMethod([self class], sel, (IMP)dynamicAdditionMethodIMP,"v@:");
    //
    //
    //    return YES;
    //
    // }
    
    
    return [super resolveInstanceMethod:sel];
}

-(void)appendString:(NSString*)str{
    
    NSLog(@"%@===%@",NSStringFromClass([self class]),NSStringFromSelector(_cmd));
    
}
@end
