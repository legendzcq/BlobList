//
//  AppDelegate.h
//  afn_demo
//
//  Created by Dean on 2018/4/17.
//  Copyright © 2018年 tz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

