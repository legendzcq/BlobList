//
//  ViewController.m
//  afn_demo
//
//  Created by Dean on 2018/4/17.
//  Copyright © 2018年 tz. All rights reserved.
//

/*
 urlStr = @"http://api.douban.com/v2/movie/top250";
 
     NSDictionary *dic = @{@"start":@(1),
     @"count":@(5)
     };
 */

#import "ViewController.h"
#import <AFNetworking.h>
#import <UIImageView+AFNetworking.h>


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    AFNetworkReachabilityManager *manager = [AFNetworkReachabilityManager manager];
    [manager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
       
        switch (status) {
            case AFNetworkReachabilityStatusUnknown:
                NSLog(@"不明网络");
                break;
            case AFNetworkReachabilityStatusNotReachable:
                NSLog(@"没有网络");
                break;
            case AFNetworkReachabilityStatusReachableViaWWAN:
                NSLog(@"蜂窝网络");
                break;
            case AFNetworkReachabilityStatusReachableViaWiFi:
                NSLog(@"WiFi"); 
                break;
            default:
                break;
        }
    }];
    
    [manager startMonitoring];
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self imageViewSetImage];
}

- (void)imageViewSetImage{
    UIImageView *imageView1 = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 100, 100)];
    UIImageView *imageView2 = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 100, 100)];

    [imageView1 setImageWithURL:[NSURL URLWithString:@"http://img3.imgtn.bdimg.com/it/u=2837434674,4026644209&fm=26&gp=0.jpg"] placeholderImage:nil];
    
    [imageView2 setImageWithURL:[NSURL URLWithString:@"http://img4.imgtn.bdimg.com/it/u=2351819279,1370470313&fm=11&gp=0.jpg"] placeholderImage:nil];

}



@end
